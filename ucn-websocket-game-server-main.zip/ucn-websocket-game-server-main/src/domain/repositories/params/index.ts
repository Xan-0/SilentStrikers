export * from './score.params';
