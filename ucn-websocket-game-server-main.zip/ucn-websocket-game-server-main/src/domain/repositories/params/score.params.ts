export type AddGameScoreParams = {
  gameId: string;
  playerName: string;
  score: number;
};
