export interface Game {
  id: string;
  name: string;
  keyword: string;
}
