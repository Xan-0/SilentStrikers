export * from './score-add.dto';
