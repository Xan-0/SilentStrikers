export * from './game.entity';
export * from './score.entity';
