export enum ETableNames {
  Game = 'game',
  Score = 'score',
}
