export enum EGameTableColumns {
  Id = 'id',
  Name = 'name',
  Keyword = 'keyword',
}
