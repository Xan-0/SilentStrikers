export * from './table-names.enum';

export * from './game-table-columns.enum';
export * from './score-table-columns.enum';
