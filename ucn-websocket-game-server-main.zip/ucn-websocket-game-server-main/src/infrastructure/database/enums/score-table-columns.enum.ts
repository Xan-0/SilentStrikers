export enum EScoreTableColumns {
  Id = 'id',
  PlayerName = 'player_name',
  Score = 'score',
  GameId = 'game_id',
}
