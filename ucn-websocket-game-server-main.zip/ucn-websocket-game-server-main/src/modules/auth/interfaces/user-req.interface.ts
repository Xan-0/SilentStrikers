export interface UserRequest {
  gameId: string;
}
