export enum ELobbyListenEvent {
  PublicMessageReceived = 'public-message',
  PrivateMessageReceived = 'private-message',
  PlayerStatusChanged = 'player-status-changed',
}
