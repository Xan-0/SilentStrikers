export enum EConnectionListenEvent {
  ConnectedToServer = 'connected-to-server',
  PlayerConnected = 'player-connected',
  PlayerDisconnected = 'player-disconnected',
}
