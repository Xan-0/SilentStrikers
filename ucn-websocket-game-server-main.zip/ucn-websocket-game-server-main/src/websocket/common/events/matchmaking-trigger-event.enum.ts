export enum EMatchmakingTriggerEvent {
  SendMatchRequest = 'send-match-request',
  CancelMatchRequest = 'cancel-match-request',
  AcceptMatch = 'accept-match',
  RejectMatch = 'reject-match',
}
