export enum ELobbyTriggerEvent {
  OnlinePlayers = 'online-players',
  SendPublicMessage = 'send-public-message',
  SendPrivateMessage = 'send-private-message',
}
