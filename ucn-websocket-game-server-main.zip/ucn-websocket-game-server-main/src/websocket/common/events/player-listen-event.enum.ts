export enum EPlayerListenEvent {
  PlayerNameChanged = 'player-name-changed',
}
