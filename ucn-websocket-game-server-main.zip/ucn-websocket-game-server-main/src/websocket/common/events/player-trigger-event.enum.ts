export enum EPlayerTriggerEvent {
  Login = 'login',
  PlayerData = 'player-data',
  ChangeName = 'change-name',
}
