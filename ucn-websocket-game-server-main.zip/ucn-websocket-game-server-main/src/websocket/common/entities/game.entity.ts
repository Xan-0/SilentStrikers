export interface Game {
  id: string;
  name: string;
  team: string;
  key: string;
}
